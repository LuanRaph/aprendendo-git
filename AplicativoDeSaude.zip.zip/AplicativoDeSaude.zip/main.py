from kivy.app import App
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.button import Button
from kivy.uix.image import Image
from kivy.uix.label import Label




class MyApp(App):
        def build(self):
            layout = FloatLayout()
            
            #layout de fundo
            background = Image(source="/storage/emulated/0/AplicativoDeSaude/images/login-menu.jpg", allow_stretch=True, keep_ratio=False)
            layout.add_widget(background)
            
            #login menu
            font = "/storage/emulated/0/AplicativoDeSaude/font/ARIBLK.TTF"
            login_text = Label(text='Login',
            font_size='60sp',
            color=(0, 0, 0, 1),
            pos_hint={'center_x': .5, 'center_y': .5},
            font_name=font)
            layout.add_widget(login_text)
            
            
     
            return layout
        
MyApp().run()
